<script setup lang="ts">
import { SidebarGroup, SidebarGroupLabel, SidebarMenu, SidebarMenuButton, SidebarMenuItem } from '@/components/ui/sidebar';
import { Link, usePage } from '@inertiajs/vue3';
import { computed } from 'vue';
import { getNavItemsByRole } from '@/composables/getNavItemsByRole';
import type { NavItem } from '@/types';

const page = usePage();
const auth = computed(() => page.props.auth);

const navItems = computed(() => {
  const user = auth.value?.user;
  if (!user?.roles || user.roles.length === 0) return [];
  return getNavItemsByRole(user);
});
</script>

<template>
  <SidebarGroup v-if="navItems.length > 0" class="px-2 py-0">
    <SidebarGroupLabel>Main Menu</SidebarGroupLabel>
    <SidebarMenu>
      <SidebarMenuItem v-for="item in navItems" :key="item.title">
        <SidebarMenuButton as-child :is-active="page.url.startsWith(item.href)">
          <Link :href="item.href">
            <component :is="item.icon" class="w-4 h-4 mr-2" />
            <span>{{ item.title }}</span>
          </Link>
        </SidebarMenuButton>
      </SidebarMenuItem>
    </SidebarMenu>
  </SidebarGroup>
</template>
